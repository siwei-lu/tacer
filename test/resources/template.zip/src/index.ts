console.log('Thanks for using tacer.')
